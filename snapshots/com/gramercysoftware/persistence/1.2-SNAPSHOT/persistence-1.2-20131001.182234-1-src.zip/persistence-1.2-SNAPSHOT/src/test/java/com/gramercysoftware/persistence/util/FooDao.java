package com.gramercysoftware.persistence.util;

import com.gramercysoftware.persistence.dao.GenericDao;

public interface FooDao extends GenericDao<Foo, Long> {

}
