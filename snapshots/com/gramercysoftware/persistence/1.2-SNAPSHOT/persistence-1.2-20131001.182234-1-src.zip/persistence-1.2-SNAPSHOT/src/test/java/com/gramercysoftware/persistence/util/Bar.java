package com.gramercysoftware.persistence.util;

public enum Bar {
	FOO, BAR, BAZ;
}
